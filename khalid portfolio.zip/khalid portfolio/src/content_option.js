
// const logotext = "Made In Heaven";
const introdata = {
  // title: "Made In Heaven",
  animated: {
    first: "I am a Frontend Developer",
    second: "I am a React Js Developer",
    third: "I build Things for Web",
  },
  description:
    " As a highly experienced Frontend Developer, I specialize  in  web design and development, consistently delivering high-quality work.",

};
const introdata1 = {
  
  animated: {
    first: "Khalid H.",
    second: "خالد",
    third: "खालिद",
  },

};




export {
  introdata,
  introdata1,
  
  
};
